###  install packages
library(doMC)
library(devtools)
#  install.packages("blotter", repos = "http://R-Forge.R-project.org")
#  install.packages("quantstrat", repos = "http://R-Forge.R-project.org")
#  install.packages("FinancialInstrument", repos = "http://R-Forge.R-project.org")
library(quantstrat)
library(zoo)
library(TTR)
#  install_github("IlyaKipnis/IKTrading")
#  install_github("IlyaKipnis/DSTrading")
library(IKTrading)
library(DSTrading)
library(lattice)
library(shiny)

###  use modified osDollarATR function
osDollarATR <- function (orderside, tradeSize, pctATR, maxPctATR = pctATR, data, 
                         timestamp, symbol, prefer = "Open", portfolio, integerQty = TRUE, 
                         atrMod = "", rebal = FALSE, ...) 
{
  if (tradeSize > 0 & orderside == "short") {
    tradeSize <- tradeSize * -1
  }
  pos <- getPosQty(portfolio, symbol, timestamp)
  atrString <- paste0("atr", atrMod)
  atrCol <- grep(atrString, colnames(mktdata))
  if (length(atrCol) == 0) {
    stop(paste("Term", atrString, "not found in mktdata column names."))
  }
  atrTimeStamp <- mktdata[timestamp, atrCol]
  if (is.na(atrTimeStamp) | atrTimeStamp == 0) {
    stop(paste("ATR corresponding to", atrString, "is invalid at this point in time. \n               Add a logical operator to account for this."))
  }
  dollarATR <- pos * atrTimeStamp
  desiredDollarATR <- pctATR * tradeSize
  remainingRiskCapacity <- tradeSize * maxPctATR - dollarATR
  if (orderside == "long") {
    qty <- min(tradeSize * pctATR/atrTimeStamp, remainingRiskCapacity/atrTimeStamp)
  }
  else {
    qty <- max(tradeSize * pctATR/atrTimeStamp, remainingRiskCapacity/atrTimeStamp)
  }
  if (integerQty) {
    if(qty >= 10000){
      qty <- signif(qty, digits = 2)
    } else if(qty >= 1000){
      qty <- signif(qty, digits = 1)
    } else if(qty > 0){
      qty <- 0
    }
  } else {
    qty <- qty
  }
  if (!rebal) {
    if (orderside == "long" & qty < 0) {
      qty <- 0
    }
    if (orderside == "short" & qty > 0) {
      qty <- 0
    }
  }
  if (rebal) {
    if (pos == 0) {
      qty <- 0
    }
  }
  return(qty)
}

###########################################
###  custom transaction costs function  ###
###########################################

###  transaction costs
###  Buying: 14.25 basis point for brokerage fee
###  Selling: 14.25 basis point for brokerage fee and 30 basis point transaction tax
buyCost <- 0.001425
sellCost <- 0.004425

### custom transaction fee function based on value of transaction
buyFee <- function(TxnQty, TxnPrice, Symbol, ...)
{
  abs(TxnQty) * TxnPrice * -buyCost
}

sellFee <- function(TxnQty, TxnPrice, Symbol, ...)
{
  abs(TxnQty) * TxnPrice * -sellCost
}

###  download stock data from yahoo
###  replace the column names of 2330.TW to tsmc
###  use splits and dividends to adjust OHLC price
tsmc <- getSymbols("2330.TW", from = "2000-01-01", to = Sys.Date(), auto.assign = FALSE)
saveSymbols(Symbols=symbols, file.path=stop(getwd()))
names(tsmc) <- gsub("2330.TW", "tsmc", names(tsmc))
tsmc <- adjustOHLC(tsmc, use.Adjusted = TRUE)

############################
###  set up working env  ###
############################

###  clean .blotter env, setting up currency, time zone and stock
rm(list = ls(.blotter), envir = .blotter)
currency("TWD")
Sys.setenv(TZ = "UTC")
symbols = "tsmc"
stock(symbols, currency = "TWD", multiplier = 1)


###  before first day of the strategy
###  naming the strategy, portfolio and account
###  determing the trade size and initial equity
initDate = "1999-01-01"
strategy.st <- portfolio.st <- account.st <- "Strat1"
tradeSize <- 150000
initEq <- tradeSize*length(symbols)


###  remove the changes of former portfolio and strategy if they have
###  initialize portfolio, account and orders
###  create strategy
rm.strat(portfolio.st)
rm.strat(strategy.st)
initPortf(portfolio.st, symbols = symbols, initDate = initDate, currency = "TWD")
initAcct(account.st, portfolios = portfolio.st, initDate = initDate, currency = "TWD", initEq = initEq)
initOrders(portfolio.st, initDate = initDate)
strategy(strategy.st, store = TRUE)




#########################
###  set up strategy  ###
#########################

### apply optimized parameters
#  RSI
nRSI = 2
thresh1 = 11
thresh2 = 9

#  MA
nSMAexit = 11
nSMAfilter = 251

#  average true range
period = 10
pctATR = .02 #  2% ATR, size the position based on risk
maxPct = .04 

##############################################
###  Notice the "arguments" in indicators  ###
###  "columns/column" in signals           ###
###  or applyStrategy may go wrong         ###
###  eg, column_name.label                 ###
##############################################

###  indicators
add.indicator(strategy.st, name = "lagATR",
              arguments = list(HLC=quote(HLC(mktdata)), n=period),
              label = "atrX")

add.indicator(strategy.st, name = "RSI",
              arguments = list(price=quote(Cl(mktdata)), n=nRSI),
              label = "rsi")

add.indicator(strategy.st, name = "SMA",
              arguments = list(x=quote(Cl(mktdata)), n=nSMAexit),
              label = "quickMA")

add.indicator(strategy.st, name = "SMA",
              arguments = list(x=quote(Cl(mktdata)), n=nSMAfilter),
              label = "filterMA")


###  signals
#  cross = FALSE, for current signal
#  cross = TRUE, for both previous day and current signal
add.signal(strategy.st, name = "sigThreshold",
           arguments = list(column = "rsi", threshold = thresh1,
                            relationship = "lt", cross = TRUE),
           label = "rsiThresh1")

#  first time enter long
add.signal(strategy.st, name = "sigAND",
           arguments = list(columns = c("rsiThresh1", "atr.atrX")),
           label = "longEntry1")

add.signal(strategy.st, name = "sigThreshold",
           arguments = list(column = "rsi", threshold = thresh2,
                            relationship = "lt", cross = TRUE),
           label = "rsiThresh2")

#  second time enter long
add.signal(strategy.st, name = "sigAND",
           arguments = list(columns = c("rsiThresh2", "atr.atrX")),
           label = "longEntry2")


#  first signal to exit
add.signal(strategy.st, name = "sigCrossover",
           arguments = list(columns = c("Close", "quickMA"), relationship = "gt"),
           label = "exitLongNormal")

#  second signal to exit
add.signal(strategy.st, name = "sigCrossover",
           arguments = list(columns = c("Close", "filterMA"), relationship = "gt"),
           label = "exitLongFilter1")

#  third signal to exit
add.signal(strategy.st, name = "sigCrossover",
           arguments = list(columns = c("Close", "filterMA"), relationship = "lt"),
           label = "exitLongFilter2")


###  rules
add.rule(strategy.st, name = "ruleSignal",
         arguments = list(sigcol = "longEntry1",
                          sigval = TRUE,
                          ordertype = "market",
                          orderside = "long",
                          replace = FALSE, #  replace = TRUE may choose just one rule
                          prefer = "Open", #  tomorrow because today has closed
                          osFUN = osDollarATR, #  order size function
                          tradeSize = tradeSize,
                          pctATR = pctATR,
                          maxPctATR = pctATR, #  set an upper limit of orders
                          atrMod = "X",
                          TxnFees = "buyFee"), #  atrx above
         type = "enter", path.dep = TRUE, label = "enterLong1")

add.rule(strategy.st, name = "ruleSignal",
         arguments = list(sigcol = "longEntry2",
                          sigval = TRUE,
                          ordertype = "market",
                          orderside = "long",
                          replace = FALSE, #  replace = TRUE may choose just one rule
                          prefer = "Open", #  tomorrow because today has closed
                          osFUN = osDollarATR, #  order size function
                          tradeSize = tradeSize,
                          pctATR = pctATR,
                          maxPctATR = maxPct, #  set an upper limit of orders
                          atrMod = "X",
                          TxnFees = "buyFee"), #  atrx above
         type = "enter", path.dep = TRUE, label = "enterLong2")

#  exit rules
add.rule(strategy.st, name = "ruleSignal",
         arguments = list(sigcol = "exitLongNormal",
                          sigval = TRUE,
                          orderqty = "all", #  order quantity, in all and out all
                          ordertype = "market",
                          orderside = "long",
                          replace = FALSE,
                          prefer = "Open",
                          TxnFees = "sellFee",
                          orderset = 'ocolong'),
         type = "exit", path.dep = TRUE, label = "normalExitLong")

add.rule(strategy.st, name = "ruleSignal",
         arguments = list(sigcol = "exitLongFilter1",
                          sigval = TRUE,
                          orderqty = "all",
                          ordertype = "market",
                          orderside = "long",
                          replace = FALSE,
                          prefer = "Open",
                          TxnFees = "sellFee",
                          orderset = 'ocolong'),
         type = "exit", path.dep = TRUE, label = "filterExitLong1")

add.rule(strategy.st, name = "ruleSignal",
         arguments = list(sigcol = "exitLongFilter2",
                          sigval = TRUE,
                          orderqty = "all",
                          ordertype = "market",
                          orderside = "long",
                          replace = FALSE,
                          prefer = "Open",
                          TxnFees = "sellFee",
                          orderset = 'ocolong'),
         type = "exit", path.dep = TRUE, label = "filterExitLong2")

#  stop loss
add.rule(strategy.st, name='ruleSignal', 
         arguments = list(sigcol="longEntry1",
                          sigval=TRUE, 
                          orderqty="all", 
                          ordertype='stoplimit', 
                          orderside='long',
                          prefer = "Open",
                          threshold=0.2, 
                          tmult=TRUE,
                          TxnFees = "sellFee",
                          orderset = 'ocolong'), 
         type='chain', parent = 'enterLong1', 
         path.dep = TRUE, label = "stopLossExit1")


add.rule(strategy.st, name='ruleSignal', 
         arguments = list(sigcol="longEntry2",
                          sigval=TRUE, 
                          orderqty="all", 
                          ordertype='stoplimit', 
                          orderside='long', 
                          threshold=0.2,
                          prefer = "Open",
                          tmult=TRUE,
                          TxnFees = "sellFee",
                          orderset = 'ocolong'), 
         type='chain', parent = 'enterLong2', 
         path.dep = TRUE, label = "stopLossExit2")




###  apply strategy
t1 <- Sys.time()
out <- applyStrategy(strategy = strategy.st, portfolios = portfolio.st)
t2 <- Sys.time()
print(t2-t1)


###  set up analytics
updatePortf(portfolio.st)

tradeDetails <- getPortfolio(portfolio.st)
posPL <- tradeDetails$symbols$tsmc$posPL

dateRange <- time(tradeDetails$summary)[-1]
updateAcct(portfolio.st, dateRange)
updateEndEq(account.st)

tStats <- tradeStats(Portfolios = portfolio.st, use = "trades", inclZeroDays = FALSE)
tStats[, 4:ncol(tStats)] <- round(tStats[, 4:ncol(tStats)], 2)

ps <- perTradeStats(Portfolio = portfolio.st)

#  plot account
getAcct <- getAccount(paste("account", account.st, sep = "."))




sma <- SMA(x = Cl(tsmc), n = nSMAfilter)
sma2 <- SMA(x = Cl(tsmc), n = nSMAexit)
rsi <- RSI(price = Cl(tsmc), n = 2)
atr <- lagATR(HLC = HLC(tsmc), n = 10)

myTheme<-chart_theme()
myTheme$col$dn.col<-'lightgray'
myTheme$col$dn.border <- 'lightgray'
myTheme$col$up.border <- 'lightgray'

tradeDetails <- perTradeStats(Portfolio = portfolio.st)[, 1:9]

orderBook <- getOrderBook(portfolio = portfolio.st)[[1]]$tsmc
orderBook <- data.frame(Date = index(orderBook), orderBook)

