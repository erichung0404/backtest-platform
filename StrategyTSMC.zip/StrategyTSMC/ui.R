library(shiny)
shinyUI(fluidPage(
  titlePanel("Strategy for TSMC"),
  sidebarLayout(
    sidebarPanel(
      helpText("The strategy is designed for TSMC"), 
      dateRangeInput("zoomRange", label = "Zoom In", start = "2000-01-01", end = Sys.Date()),
      actionButton("start", "Start"),
      br(), 
      br(),
      selectizeInput("choice", "Select one table to download", 
                     choices = c("Daily Price" = "tsmc",
                                 "Trade Details" = "tradeDetails",
                                 "Order Book" = "orderBook")),
      downloadButton("downloadData", label = "Download")
    ),
    mainPanel(
      tabsetPanel(
        type = "tabs",
        tabPanel("Data", dataTableOutput("dataTable")),
        tabPanel("Trading Details", dataTableOutput("tradeTable")),
        tabPanel("Order Book", dataTableOutput("orderBook")),
        tabPanel("Backtest Result", uiOutput("backtest"))
      )
    )
  )
))