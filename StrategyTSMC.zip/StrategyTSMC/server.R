###  install packages
library(doMC)
library(devtools)
#  install.packages("blotter", repos = "http://R-Forge.R-project.org")
#  install.packages("quantstrat", repos = "http://R-Forge.R-project.org")
#  install.packages("FinancialInstrument", repos = "http://R-Forge.R-project.org")
library(quantstrat)
library(zoo)
library(TTR)
#  install_github("IlyaKipnis/IKTrading")
#  install_github("IlyaKipnis/DSTrading")
library(IKTrading)
library(DSTrading)
library(lattice)
library(shiny)

shinyServer(function(input, output){
  
  action <- eventReactive(input$start, {})
  newDate <- eventReactive(input$start, {
    paste0(input$zoomRange[1], "/", input$zoomRange[2])
  })
  
  output$dataTable <- renderDataTable({
    action()
    tsmc <- data.frame(Date = index(tsmc), tsmc)
  })
  
  output$tradeTable <- renderDataTable({
    action()
    tradeDetails <- perTradeStats(Portfolio = portfolio.st)[, 1:9]
    tradeDetails
  })
  
  output$orderBook <- renderDataTable({
    action()
    orderBook <- getOrderBook(portfolio = portfolio.st)[[1]]$tsmc
    orderBook <- data.frame(Date = index(orderBook), orderBook)
    orderBook[, -ncol(orderBook)]
  })
  
  output$downloadData <- downloadHandler(
    filename = function(){
      paste0(input$choice, ".csv")
    },
    content = function(file){
      write.csv(get(input$choice), row.names = FALSE, file)
    }
  )
  
  output$backtest <- renderUI({
    dataList <- list(chartPos = plotOutput("chartPos"),
                     acctInfo = plotOutput("acctInfo"),
                     endEq = plotOutput("endEq"),
                     barPos = plotOutput("barPos"),
                     MAE = plotOutput("MAE"),
                     MFE = plotOutput("MFE"),
                     tStats = tableOutput("tStats"))
    do.call(tagList, dataList)
  })
  local({
    output$chartPos <- renderPlot({
      action()
      
      # Create a Progress object
      progress <- shiny::Progress$new()
      progress$set(message = "(╯￣▽￣)╯Loading...", value = 0)
      
      # Close the progress when this reactive exits (even if there's an error)
      on.exit(progress$close())
      
      chart.Posn(Portfolio = portfolio.st, Symbol=symbols, theme= myTheme)
      add_TA(sma2, on = 1, col = "red")
      add_TA(sma, on = 1, col = "green")
      add_TA(rsi, col = "purple", lwd = 1.5)
      
      zoom_Chart(newDate())
      
    })
    
    output$barPos <- renderPlot({
      action()
      chart.Histogram(ps$Pct.Net.Trading.PL, methods=c('add.centered'), 
                      main=paste0('Luxor returns\n', '(Odds=', tStats$Percent.Positive, '%)'))
    })
    
    output$acctInfo <- renderPlot({
      action()
      xyplot(getAcct$summary, type = "h", col = 4)
    })
    
    output$endEq <- renderPlot({
      #  equity curve
      action()
      chart.TimeSeries(getAcct$summary$End.Eq, type = "h", col = 4)
    })
    
    output$MAE <- renderPlot({
      action()
      chart.ME(Portfolio = portfolio.st, Symbol = symbols, 
               type = "MAE", scale = "percent")
    })
    
    output$MFE <- renderPlot({
      action()
      chart.ME(Portfolio = portfolio.st, Symbol = symbols, 
               type = "MFE", scale = "percent")
    })
    
    output$tStats <- renderTable({
      action()
      t(tStats[, -c(1, 2)])
    })
  })
})
